## Requerimientos

- Se necesitan instalar requerimientos en su computadora o en un entorno virutal con el sig comando:

```
pip install -r requeriments.txt
```

## Instrucciones de ejecucion

- 1a) python3 Ejercicio1a.py
- 1b) python3 Ejercicio1b.py
- 2) python3 ej3.py
  
## Notas

- Para mejor visualizacion y adaptacion a cualquier sistema windows/ubuntu los graficos son guardados en archivos png para no depender de la posibilidad de generar multiples displays 

- Es muy importante tener la carpeta graficos donde se guardaran los resultados
   
