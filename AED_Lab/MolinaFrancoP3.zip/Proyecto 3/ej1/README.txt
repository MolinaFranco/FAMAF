ingrese un valor para x:7
ingrese un valor para y:3
ingrese un valor para z:5
x + y + 1 = 11
z * z + y * 45 - 15 * x = 55
y - 2 == (x * 3 + 1) % 5 => True
y / 2 * x = 7
y < x *z = 1



ingrese un valor para x:1
ingrese un valor para y:10
ingrese un valor para z:8
x + y + 1 = 12
z * z + y * 45 - 15 * x = 499
y - 2 == (x * 3 + 1) % 5 => True
y / 2 * x = 5
y < x *z = 0