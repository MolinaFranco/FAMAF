x = 4 
y = -4 
z = 8 
b = true 
w = false