σ0
Ingresar un valor para x: 5
Ingresar un valor para y: 4
Ingresar un valor para z: 8
Ingresar un valor para m: 0

σ1
El valor de x es: 5
El valor de y es: 4
El valor de z es: 8
El valor de m es: 5

σ2
El valor de x es: 5
El valor de y es: 4
El valor de z es: 8
El valor de m es: 5


σ0
Ingresar un valor para x: 1
Ingresar un valor para y: 2
Ingresar un valor para z: 3
Ingresar un valor para m: 4

σ1
El valor de x es: 1
El valor de y es: 2
El valor de z es: 3
El valor de m es: 1

σ2
El valor de x es: 1
El valor de y es: 2
El valor de z es: 3
El valor de m es: 1