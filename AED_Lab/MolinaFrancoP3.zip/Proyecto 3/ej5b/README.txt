Ingresar un valor para x: 13
Ingresar un valor para y: 3
Ingresar un valor para i: 0

σ0
El valor de x es: 10
El valor de y es: 3
El valor de i es: 1

σ1
El valor de x es: 7
El valor de y es: 3
El valor de i es: 2

σ2
El valor de x es: 4
El valor de y es: 3
El valor de i es: 3

σ3
El valor de x es: 1
El valor de y es: 3
El valor de i es: 4
