Ingresar un valor para x: 5
Ingresar un valor para i: 0
Ingresar un valor para r: False

σ0
Los valores son, x: 5 i: 3 res: 1

σ1
Los valores son, x: 5 i: 4 res: 1

σ3
Los valores son, x: 5 i: 5 res: 1


Otros ejem:

Ingresar un valor para x: 10
Ingresar un valor para i: 5
Ingresar un valor para r: True

σ0
Los valores son, x: 10 i: 3 res: 0

Ingresar un valor para x: 10
Ingresar un valor para i: 5
Ingresar un valor para r: False

σ0
Los valores son, x: 10 i: 3 res: 0