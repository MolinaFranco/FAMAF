Aclaracion:

Ya que uso un makefile asi q el programa necesito llamarlo main.c pero funciona igual que entrada.c
