#include <stdio.h>
#include "../ej6a/entrada.c"

int main(void)
{
    int x;
    x = pedirEntero();
    imprimeEntero(x);

    return 0;
}