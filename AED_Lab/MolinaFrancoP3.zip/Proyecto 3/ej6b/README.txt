Aclaracion: 

Yo en los ejercicios anteriores ya los habia realizado con funciones auxiliares
Las funciones auxiliares estan en un doc llamado auxiliar.c

Utilizar funciones auxiliares ayuda a ahorrar codigo repetido

Aparte de estas funciones pordria realizarlo con un for()

Utilize mis funciones auxiliares en casi todos los otros ejer. por esto no necesite reescribir nada

