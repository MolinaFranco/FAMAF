saludo.c y main.c contienen lo mismo
por comodidad de la creacion y ejecucion de los programas creo el archivo main para poder ejercutarlos mas facil
pero como la tarea solicita un saludo.c tmb lo genero