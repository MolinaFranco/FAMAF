# Requerimientos

```
pip install -r requeriments.txt
```

# Instrucciones

- 1) N/c
- 2) python3 ej2.py
- 3) python3 ej3.py
- 4) N/c
- 5) python3 ej5.py
  
# Notas

- Todas las funciones auxiliares (extras a los solicitado) estan en helper.py

- Las preguntas del ej5 estas respondidas en el mismo archivo ej5.py